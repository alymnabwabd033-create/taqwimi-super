
package com.realityscan3d.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.realityscan3d.app.ui.screens.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RealityScanApp() {
    val navController = rememberNavController()
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("REALITY SCAN 3D — PRO") }) },
            bottomBar = { NavigationBar {
                NavigationBarItem(selected=true, onClick={navController.navigate("scan")}, label={Text("مسح")}, icon={})
                NavigationBarItem(selected=false, onClick={navController.navigate("projects")}, label={Text("مشاريعي")}, icon={})
                NavigationBarItem(selected=false, onClick={navController.navigate("viewer")}, label={Text("العارض 3D")}, icon={})
            }}
        ) { pad ->
            NavHost(navController, startDestination="scan", modifier=Modifier.padding(pad)) {
                composable("scan") { ScanScreen() }
                composable("projects") { ProjectsScreen() }
                composable("viewer") { Viewer3DScreen() }
            }
        }
    }
}
