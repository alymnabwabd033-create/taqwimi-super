
package com.realityscan3d.app.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ProjectsScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        items(5) { i ->
            Card(Modifier.fillMaxWidth().padding(vertical=8.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("مشروع ${i+1}: غرفة معيشة - ${2.3+i}M نقاط", style=MaterialTheme.typography.titleMedium)
                    Text("التاريخ: 2026-10-08 | الحجم: ${120+i*30}MB | PLY+GLB")
                    Row { Button(onClick={}) { Text("فتح في العارض") }; Spacer(Modifier.width(8.dp)); OutlinedButton(onClick={}) { Text("تصدير") } }
                }
            }
        }
    }
}
