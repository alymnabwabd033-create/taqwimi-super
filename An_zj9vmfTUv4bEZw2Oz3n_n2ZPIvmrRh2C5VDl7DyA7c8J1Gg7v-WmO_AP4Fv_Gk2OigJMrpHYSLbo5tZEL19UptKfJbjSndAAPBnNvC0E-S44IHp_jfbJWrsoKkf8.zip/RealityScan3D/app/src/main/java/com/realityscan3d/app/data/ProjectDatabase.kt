
package com.realityscan3d.app.data

import androidx.room.*

@Entity
data class ScanProject(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val frameCount: Int,
    val pointCount: Long,
    val meshPath: String,
    val glbPath: String,
    val scaleFactor: Float
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM ScanProject ORDER BY createdAt DESC")
    fun getAll(): List<ScanProject>
    @Insert fun insert(p: ScanProject)
    @Delete fun delete(p: ScanProject)
}

@Database(entities=[ScanProject::class], version=1)
abstract class AppDatabase: RoomDatabase() {
    abstract fun projectDao(): ProjectDao
}
