
package com.realityscan3d.app.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun Viewer3DScreen() {
    var scale by remember { mutableStateOf("1:1 حقيقي") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("العارض ثلاثي الأبعاد PRO", style=MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth().height(400.dp).padding(top=16.dp)) {
            Box(Modifier.fillMaxSize()) { Text("Filament PBR Renderer\n- تدوير/تكبير/قياس\n- وضع القياس بالمتر\n- قطع مقطعي Cross-Section\n- وضع AR", Modifier.padding(16.dp)) }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) {
            Button(onClick={}) { Text("قياس المسافة") }
            Button(onClick={}) { Text("حساب المساحة") }
            Button(onClick={}) { Text("مشاركة GLB") }
        }
        Text("المقياس: $scale | الدقة: 2mm | السطوع PBR")
    }
}
