
# REALITY SCAN 3D — ماسح العالم الحقيقي ثلاثي الأبعاد — إصدار PRO الضخم

## ماذا يفعل؟
- يصور المكان بـ CameraX + ARCore Depth API (يدعم LiDAR في أجهزة Pro)
- يجمع 120-300 صورة + مصفوفة الوضعية Pose + IMU
- يمررها عبر خط أنابيب Photogrammetry:
  1. Feature Extraction (SIFT/ORB)
  2. SfM - Structure from Motion
  3. MVS - Dense Point Cloud
  4. Meshing - Poisson / Delaunay
  5. Texturing PBR + Optimize + Scale بالمتر
- يعرض النموذج بـ Filament PBR ويسمح بالقياس الحقيقي والتصدير GLB/OBJ/PLY/STL/E57

## كيف تشغل المشروع؟
1. افتح مجلد RealityScan3D في Android Studio Hedgehog+
2. وافق على تثبيت NDK و CMake
3. وصل هاتف ARCore وشغل

## البنية:
- MVVM + Compose + Room
- Scan Engine: Kotlin + C++ NDK
- Viewer: Filament + ARCore

## تصدير:
يدعم مشاركة النموذج عبر glTF 2.0

بناء: عبدالله - Ibb, YE
